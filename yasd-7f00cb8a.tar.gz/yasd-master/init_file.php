<?php

namespace Yasd;

printf("\e[32m%s\e[0m", "[yasd] execute init_file success\n");

// require './plugin/trace_function.php';
require './plugin/analyze_function.php';
