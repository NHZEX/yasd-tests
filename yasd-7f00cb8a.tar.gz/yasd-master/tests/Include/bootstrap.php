<?php

! defined('BASE_PATH') && define('BASE_PATH', dirname(__DIR__, 2));
! defined('TEST_PATH') && define('TEST_PATH', BASE_PATH . '/tests');

require BASE_PATH . '/vendor/autoload.php';
